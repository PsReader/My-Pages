// Public Supabase browser configuration for Type Bound.
// This key is intended for frontend use; database access is protected by RLS.
window.TYPE_BOUND_SUPABASE = {
  url: 'https://fvkcadcvnqwvytjjaejb.supabase.co',
  publishableKey: 'sb_publishable_lzo5L-mtXUEtfauz3KHBSg_G-J8xMGg',
  // Metered TURN is intentionally disabled. Static TURN credentials shipped in
  // a public bundle let anyone burn the Metered relay quota on demand. STUN
  // below stays active; add a server-issued ephemeral credential if relay is
  // required for strict NATs.
  turn: {
    urls: [],
    username: '',
    credential: ''
  }
};
