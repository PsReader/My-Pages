# Hexfall acceptance outcomes

- [x] The browser app provides a responsive expedition map that presents the compact dungeon-crawler loop and launches the authored battle encounter.
- [x] The battle screen provides a prestige-scaled 9×7-to-18×11 hex board with valid-cell highlighting, clear unit silhouettes, occupancy rules, and responsive desktop/touch interaction.
- [x] Turn-based combat supports movement, basic attack, and guard with clear selection, targeting, confirmation, and action feedback.
- [x] The party includes Warden, Emberling, and Wayfarer, each with a distinct combat identity and one signature ability.
- [x] The encounter includes Husk, Lantern Wisp, and Rootmother with differentiated behaviors and roles.
- [x] Enemy AI reveals readable next-action intent previews, including targets or danger areas where appropriate.
- [x] The battle uses five-round survival on regular rooms, five-round target-kill deadlines on sub-boss/boss rooms, and seven-round Big Bad objectives (eight rounds for the floor-1,000 Worldbreaker), with explicit victory/defeat states.
- [x] The post-battle flow presents a reward and returns the player to the expedition experience.
- [x] The app autosaves after confirmed actions and supports reload/continue through versioned, namespaced localStorage data with a backup save key.
- [x] Settings expose JSON save export/import with validation and safe recovery, while simulation state remains separate from rendering state.
- [x] The visual system uses original Hexfall branding, ink/ember/moonlight colors, authored copy, deliberate motion, and responsive layouts rather than copied Hexa Battle assets or branding.

- [x] Battle controls remain responsive and phase-valid: clicking an enemy unit or turn-order target reaches the active Attack/signature targeting logic; the self/ally-targeted Warden Brace Line triggers without requiring an enemy; legal enemy targets are highlighted and invalid targets receive clear feedback.
- [x] Battle audio feels urgent and percussive, with an adaptive combat score and punchier action/impact cues while preserving volume, mute, and reduced-motion/accessibility settings.
- [x] Victory and defeat use custom animated SVG transition screens with distinct radiating/reward and fractured/fading treatments; reduced-motion mode suppresses nonessential animation.
- [x] Selecting a combat character displays a class-colored glowing aura and movement particle trail; class emblems react to hover/focus/current selection with class-specific glow and particle accents.
- [x] Returning from a completed battle offers the correct next-floor action instead of restoring a stale result as an active battle.

- [x] Mobile battle interaction keeps the hex board swipeable with enlarged unit tap targets, an action dock pinned below the detail pane, and controls padded for device safe areas.
- [x] Touch Haptics can be toggled in Field Settings; supported browsers use short vibration patterns and unsupported browsers show a brief visual pulse.
- [x] The Rift Stalker telegraphs a blink landing before its follow-up attack, and the Moss Oracle marks a hero so the next enemy hit deals +1 damage; both enter regular floors from the stated progression tiers.
- [x] Ash Colossus quake and Bell Widow webfall/summon turns expose their threatened tiles before enemy resolution.

- [x] The battle field replaces the flat black panel with a dark, readable dungeon-hall background, restrained torchlight, and stone depth without a large logo/rune overlay.

- [x] Every Main Class, party hero, regular enemy, and boss has a bespoke Hexfall sigil; the marks appear in class cards, battlefield units, turn order, and party status, with the selected Main Class sigil carried by the Warden.

- [x] The market offers eight randomized items per visit from a 21-relic catalogue, rerolls when reopened, and shows a distinct custom SVG, rarity, tier, effect, and cost on every offer.
- [x] Relics persist for a run and each offer can be bought once per visit; an owned relic becomes available for its next upgrade tier when it returns in a later roll. Individual caps (I–III), scaling shard prices, and tiered combat/reward effects are persisted.
- [x] The hub saves a fixed Main Class plus prestige-scaled swappable companion slots (up to six recruits); newly unlocked and repeated classes can join, and deployed companions earn persistent XP toward five stat-boosting promotion levels.
- [x] Browser smoke tests cover eight illustrated shop offers, Echo Charm I→II purchase cost, market rerolls, saved roster changes, XP promotions, and upgraded stats in a new battle.

- [x] A persistent accessible Field Guide explains turn order, optional movement, one action per ally, highlighted targets, enemy intent, class XP, market tiers, and ember/meta-shard uses; it closes by button, backdrop, or Escape.
- [x] The hub presents a three-step quick start; battle prompts state the objective, explain optional movement, warn how many unused heroes will be skipped, and describe Guard protection.
- [x] Starting a new expedition confirms which run data will reset and preserves permanent progression, party, class growth, badges, history, and settings.
- [x] Every formation has an immutable Main Class in slot 1 and prestige-unlocked recruit slots; existing saves migrate without losing unlocked classes, XP, levels, or the chosen Main Class.
- [x] Companions can be swapped on the hub and again during the battle deployment window before any valid ally action; the window locks after the first action, and deep-floor unlocks enter the companion pool.
- [x] Companion-only XP promotions are separate from the selected Main Class’s three permanent, class-specific Meta-shard ranks; switching Main Classes preserves each class’s ranks, which affect its deployed stats and signature.
- [x] Browser UI checks verify migration, fixed slot controls, hub/deployment swaps, per-class mastery purchases, active Main Class stats, and action lock without runtime errors.

- [x] The Meta Tree clearly separates general team-wide benefits, owned Main Class selection, unbought Main Class purchases, selected-class mastery, and combination synergies.
- [x] Meta Tree diagrams show the complete branch structure without crossing prerequisites; locked future nodes are dimmed, and progression cards list owned plus next prerequisite-ready purchases regardless of current shard balance.
- [x] Locked general and class-tree nodes explain only their missing prerequisites in hover, focus, and touch tooltips; multi-prerequisite labels fit within narrow mobile viewports.
- [x] Hub, battle, shop, and Meta Tree are checked at 320, 375, 430, 481, 540, 768, 1024, and 1280px; the 320px party picker and menu remain in-bounds.
- [x] Fresh saves get contextual first-encounter guidance through movement, action, and enemy resolution; tutorial step persists on reload, can be skipped, and is not injected into existing saves.
- [x] Riftblade, Stormcaller, and Soulweaver can be purchased as Main Classes, each with an original framed SVG sigil and a distinct movement profile, basic-attack trait, and signature ability.
- [x] All Main Class cards show base HP/damage/range/movement, explain their basic-attack trait and signature, and let an unlocked class become the fixed Main Class without clearing its stored mastery.
- [x] Battle targeting supports Riftblade’s extended blink range and Soulweaver’s no-target team-support signature; combat effects match every class’s displayed trait.
- [x] Browser checks cover class purchases, duplicate party use, saved Main Class selection, per-class mastery, class-specific attacks/signatures, and responsive Meta Tree layout.

- [x] Rooms 5, 15, 25… are reinforced sub-boss encounters (alternating Rift Stalker Alpha/Moss Oracle Prime); rooms 10, 20, 30… are full boss encounters, so tenth rooms never double as sub-boss rooms.
- [x] Sub-bosses have stronger room-scaled stats, a distinct battle/inspector label, two escort enemies that scatter when the target falls, and a +2 ember-shard bounty; full bosses retain unique mechanics and signature drops.
- [x] Boss and sub-boss targets must be defeated within five rounds; failing the deadline is a loss while ordinary rooms still award victory for surviving five rounds. UI tests verify target-kill rewards and timeout behavior.
- [x] Relic-market access is offered only after even-numbered rooms (2, 4, 6…); victory messaging previews the next scheduled stop, and the market explains the two-room interval.
- [x] The daily challenge mode, modifier system, entry UI, and related styles are removed; legacy save challenge fields are migrated out while run history remains.
- [x] Floors 1–100 are the standard descent; floors 101–1,000 are Prestige I–IX, with rank capped at IX and the run marked complete after floor 1,000.
- [x] Every two prestige ranks add one active companion (three through Prestige I, up to seven at Prestige VIII–IX); the Main Class remains fixed and any available class can be repeated in companion slots.
- [x] Enemy HP/damage and encounter count rise every two prestige ranks; the battlefield grows with every prestige from 9×7 to 18×11 and can be swipe-scrolled on mobile.
- [x] Every 100th room is a named Big Bad with a seven-round deadline (eight at floor 1,000), scaled escorts/stats, and a milestone bounty; the final market remains available after floor 1,000 without allowing a replay.
- [x] Browser checks cover prestige/party-size breakpoints, duplicate selections, board dimensions, Big Bad milestones, floor-1,000 completion, and the final market route.


- [x] Fresh-browser startup now renders the interactive expedition hub: legacy talent definitions are initialized before saved-state normalization, and the HTML cache key is bumped so browsers fetch the repaired JavaScript and CSS.
- [x] Adaptive music scheduling no longer reads battle-only boss/deep-descent variables from non-battle screens; hub interactions and the first battle round complete without uncaught runtime errors.
- [x] Training Grounds Ultimate previews record damage, custom enemy-stat changes reset the analytics safely while an input is focused, and custom enemy presets save/load without runtime errors.
- [x] JSON save export/import round-trips a valid save; the first battle supports movement, Guard, autosave, and enemy-turn resolution.
- [x] Hub, Meta Tree, Training Grounds, Codex, Archive, and battle layouts render at 320, 375, 430, 768, 1024, and 1280 CSS pixels with no page-level horizontal overflow; mobile battle actions meet the 48px minimum target height.
- [x] The mobile relic market renders all eight relic offers and three companion offers; a relic purchase, companion recruitment, and Meta Tree upgrade update the isolated run correctly without JavaScript errors.
- [x] The Codex displays every known enemy type with locked silhouettes, common/elite/boss filters, completion progress, combat stats, descriptions, and NEW discovery markers.
- [x] Training Grounds offers Balanced Trial, Elite Gauntlet, and Boss Chamber presets, shows an enemy-team preview with HP/damage/range, and supports rematching the last drill.
- [x] Combat shows an IN RANGE label on legal enemy targets and exposes selected enemy power, guard, and status details in the inspector.
- [x] Boss, sub-boss, and Big Bad rooms receive distinct visual emphasis; Field Settings include combat speed and color-assist controls with save migration.
