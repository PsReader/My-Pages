# Hexfall: Hexa Battle. Implementation plan

## Product scope

Build a fully browser-based tactical dungeon crawler inspired by Hexa Battle. The first playable slice includes an expedition map, one authored four-round survival encounter, three heroes, three enemy families, readable intent previews, rewards, localStorage persistence, JSON save management, and responsive mouse/touch interaction. No account or backend is needed.

## Implementation approach

- Use a dependency-free HTML/CSS/JavaScript app so the ZIP is immediately runnable with any static server.
- Keep simulation state in a serializable `state` object and keep SVG/DOM rendering in separate functions.
- Use axial-like row/column hex coordinates rendered as pointy-top SVG polygons.
- Use deterministic, one-turn enemy intent scoring rather than hidden multi-turn planning.
- Persist after every confirmed action, round transition, battle outcome, and route choice.
- Use an authored visual system: ink, ember, and moonlight; asymmetrical tactical layout; quiet stone textures; short human-written copy.

## Design movement

**Ink-and-paper tactics with ember-lit interface choreography.** The game should feel like a hand-inked field journal made tactile through SVG, not like a generic fantasy dashboard.

### Core principles

1. **Readable before clever:** every threat exposes its target or danger area.
2. **Board first:** the map owns the screen; panels support decisions instead of competing with it.
3. **Restrained drama:** limited palette, sharp silhouettes, and short motion accents.
4. **Human copy:** compact labels such as `YOUR PLAN`, `Brace the line`, and `The ward is holding`.

### Color philosophy

Near-black blue gives the board a quiet night-sky ground. Warm stone surfaces make the tactical space feel physical. Cyan belongs to the player's party and signals possibility; muted crimson belongs to enemy intent and pressure. Ember orange is the ownable Hexfall color: danger, confirmation, and the moment an attack lands. Aged gold is reserved for rewards and completed route nodes.

### Layout paradigm

Use an off-center expedition desk: the board is the large left/center field, while a narrow right-side “field note” column describes the selected unit and objective. On small screens, that column becomes a bottom sheet. Avoid centered marketing cards and excessive dashboard grids.

### Signature elements

- Etched hex board with faint coordinate-like linework.
- Intent ribbons that point from each enemy toward its threatened tile or target.
- A small ember/sigil mark used in the wordmark, buttons, and reward moments.

### Interaction philosophy

Every interaction should answer: what can I do, what will it cost, and what will happen next? Selecting a hero highlights legal movement; choosing an action narrows the board to valid targets; confirming a plan resolves only what is visible. Touch targets remain generous and never require hover.

### Animation

Use short, deliberate transitions: unit movement 180ms, attack anticipation 90ms, hit feedback 120ms, damage numbers 450ms. Avoid constantly moving backgrounds. Threat previews can pulse once on reveal, then remain still.

### Typography system

Use `Georgia` as a display serif for chapter/hero labels and a system humanist sans stack for controls and body copy. Headings are compact and letter-spaced; mechanics use high-contrast, sentence-case labels rather than all-caps everywhere.

### Brand essence

**A pocket-sized tactical expedition for players who like to think one turn ahead.**  
Personality: **quiet, sharp, ember-warm**.

### Brand voice

Headlines are evocative but brief. CTAs are specific and active. Microcopy explains consequences, never marketing claims.

- `The ruin remembers every step.`
- `Commit the plan. Let the dark answer.`

### Wordmark and signature color

The wordmark is `HEXFALL` with a small broken hex/sigil woven into the letterform. The signature brand color is ember orange `#E46F45`, used sparingly so it remains ownable.

## Project structure

```text
hexfall/
├── index.html                 # app shell and semantic UI regions
├── src/
│   ├── main.js                # simulation, AI, turn manager, rendering, persistence
│   └── styles.css             # responsive visual system and motion
├── public/
│   ├── images/                # static visual assets
│   └── sigils/                # class and relic artwork
├── package.json               # static-server scripts and metadata
├── README.md                  # local run and feature notes
├── plan.md                    # this implementation plan
└── TODO.md                    # acceptance outcomes
```

## Serving model

The app is static and listens on port 3000 through `python3 -m http.server 3000`. The managed Preview uses the same listener. The ZIP includes all source files; no `node_modules` or external service credentials are required.


## Combat reliability and SVG presentation update

- Preserve the dependency-free static browser architecture and its serializable combat state; route enemy SVG and turn-order clicks into the same validated targeting logic as board-cell clicks. Self/ally signature actions resolve directly, while enemy-targeted signatures remain range-checked and visibly highlighted.
- Keep combat phase guards authoritative for player actions. Disabled controls and action hints should reflect whether a unit can act and whether a target is in range.
- Give combat a faster, lower-register, percussion-led adaptive Web Audio arrangement, with battle heat rising by round and boss presence. Keep user volume/mute controls and short, distinct action/impact cues.
- Use custom inline SVG for a radiating victory ward and fractured defeat ward; animate the reveal and particles with CSS while respecting the existing reduced-motion setting.
- Make the selected unit carry its class-colored SVG aura. Movement draws a short-lived SVG path and animated particle trail; class emblems use class-specific glow and particles on hover, focus, and current selection.

## Refinement pass: archive clarity and practice-room depth
- Preserve the ink/ember/moonlight dungeon language while making progression legible at a glance.
- Expand the Codex into a completion archive with locked silhouettes, category filters, discovery markers, combat stat cards, and translated enemy behavior.
- Expand Training Grounds with readable room presets, enemy-team previews, codex-gated selection, and one-click rematches while keeping all drills reversible.
- Keep the combat board primary: show in-range labels and selected-enemy power/status details without replacing the existing board range treatment.
- Add room-specific visual emphasis for sub-boss, boss, and Big Bad chambers, plus combat-speed and color-assist controls that remain local and save-compatible.
